/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.algo.drone.simulation;

import java.util.Hashtable;

/**
 *
 * @author Snehal
 */
public class MachineLearning {

    public static Hashtable<Node, PathNodeLinkedList> learning = new Hashtable<Node, PathNodeLinkedList>();

}
